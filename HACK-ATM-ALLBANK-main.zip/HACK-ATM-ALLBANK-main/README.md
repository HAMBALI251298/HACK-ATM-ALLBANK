#!/system/xbin/bash
clear
blue='\e[1;34m'
green='\e[1;32m'
purple='\[1;35m'
cyan='\e[1;36m'
red='\e[1;31m'
white='\e[1;37m'
yellow='\e[1;33m'
sleep 1
echo "\033[32;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
toilet -f standard -F gay "HACKBANK"
echo "\033[31;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
echo ""
echo "Author  : "Mr.HAMBALI"
" Team.  : "HAMBALI CYBER TEAM"
echo " Kontak Me  : "083128356342"
" Pesan  : "Jangan Di Salah Gunakan Dan Disebar :) Karena Nanti Dosa Tanggung Saya Sendiri:)"
sleep 1
echo "ThanksTo : ALL MEMBER MR.HAMBALI"
echo "Gmail : hambali221019@gmail.com"
echo "\033[33;1m=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*"
echo ""

echo ="Pilih Nama Bank Anda:BCA,BRI,BNI,MANDIRI,BSI,OSCB,MUAMALAB,OVO,DANA,GOPAY,LINKAJA,POSPAY"
read p;
sleep 1
sleep 2
sleep 3
echo ="Masukkan Nama Bank Anda";
read p;
sleep 1
echo ="Masukkan No Rekening Anda"
read p;
sleep 1
sleep 2
echo ="Sebutkan Nominal Minimal Rp.1000.000.000.000- Jika Bukan Rp.1000.000.000.000- Tidak Akan Kekirim !!!"
read p;
sleep 1
sleep 2
sleep 3
sleep 4
sleep 5
sleep 6
sleep 7
sleep 8
sleep 9
echo ="Transfer Rp 1000.000.000.000 - Sukses Uang Sudah Terkirim"
sleep 1
sleep 2
echo ="Ketik Ya Jika Mau Coba Lagi Ketik Tidak Jika Tida Mau Coba Lagi"
read p;
sleep 1
sleep 2
sleep 3
sleep 4
sleep 5


echo "Pesan:Gunakanlah Dengan Sebaik Mungkin Jangan Beritahu Ini Kepada Orang Lain:)"
sleep 1
sleep 2
echo "ThankSToo"
echo "ALL MEMBER MR HAMBALI CYBER TEAM"
sleep 1
sleep 2
echo " Thank You And SeeYou Friend :*"
sleep 1
sleep 2

